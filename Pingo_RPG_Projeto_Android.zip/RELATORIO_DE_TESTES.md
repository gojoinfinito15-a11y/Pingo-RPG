# Verificações desta entrega

- Arquivo `index.html` corresponde à versão unificada mais recente com correção do endereço do servidor local Android.
- Três modos: Aventura, PvP e BR preservados no HTML do aplicativo.
- 16 recursos de imagem dos 8 heróis incluídos em `assets/`.
- Código do servidor Python preservado em `servidor/`.
- Manifest Android com orientação horizontal e INTERNET.
- Código Java com tela cheia, WebViewAssetLoader, importação de arquivos e opção de exportar saves.
- `compileSdk=36`, `targetSdk=36`, `minSdk=29`.
- Não compilado nem executado num dispositivo Android nesta sessão por ausência do Android SDK/Gradle no ambiente.
- Multiplayer **não está hospedado**; configuração WSS necessária.
