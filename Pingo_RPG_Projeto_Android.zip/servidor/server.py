"""Pingo RPG - servidor de arena PvP (FastAPI + WebSocket).

O servidor decide deslocamento, colisão, dano, resultados e estatísticas.
Nenhuma conta é criada: o token salvo no navegador identifica um perfil de teste.
"""
from __future__ import annotations

import asyncio
import json
import math
import os
import random
import re
import secrets
import sqlite3
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv('PINGO_DB', str(ROOT / 'pvp_stats.sqlite3')))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
WORLD_W, WORLD_H = 1500, 600
FLOOR = 492
TICK = 1 / 30
DURATION = 150
HEROES = ('pingo', 'mila', 'toru', 'brico', 'lyn', 'noctis', 'kaze', 'bruma')
MAPS = ('ruinas_lunares', 'torre_eclipse', 'pantano_luar')
HERO_BASIC = {'pingo': 11, 'mila': 10, 'toru': 10, 'brico': 10, 'lyn': 9, 'noctis': 11, 'kaze': 11, 'bruma': 12}
HERO_SKILL = {
    'pingo': ('Rajada de Penas', 4.5),
    'mila': ('Chama da Raposa', 5.5),
    'toru': ('Onda de Pedra', 6),
    'brico': ('Engrenagem Giratória', 5),
    'lyn': ('Flecha Perfurante', 4.5),
    'noctis': ('Corte da Foice', 5.5),
    'kaze': ('Corte Duplo', 5.5),
    'bruma': ('Martelo Sísmico', 6),
}

app = FastAPI(title='Pingo RPG Arena Online')
app.mount('/assets', StaticFiles(directory=ROOT / 'assets'), name='assets')


def db_connect():
    db = sqlite3.connect(DB_PATH)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('CREATE TABLE IF NOT EXISTS profiles (token TEXT PRIMARY KEY, nick TEXT NOT NULL, kills INTEGER DEFAULT 0, deaths INTEGER DEFAULT 0, wins INTEGER DEFAULT 0, losses INTEGER DEFAULT 0, games INTEGER DEFAULT 0, rating INTEGER DEFAULT 1000)')
    db.commit()
    return db


def profile_get(token: str):
    with db_connect() as db:
        r = db.execute('SELECT nick,kills,deaths,wins,losses,games,rating FROM profiles WHERE token=?', (token,)).fetchone()
    if not r:
        return None
    return dict(zip(('nick', 'kills', 'deaths', 'wins', 'losses', 'games', 'rating'), r))


def profile_create(token: str, nick: str):
    with db_connect() as db:
        db.execute('INSERT OR IGNORE INTO profiles(token,nick) VALUES (?,?)', (token, nick))
        db.execute('UPDATE profiles SET nick=? WHERE token=?', (nick, token))
        db.commit()
    return profile_get(token)


def profile_reward(token: str, wins=0, losses=0, kills=0, deaths=0, rated=False):
    delta = (20 if wins else -12 if losses else 0) if rated else 0
    with db_connect() as db:
        db.execute('UPDATE profiles SET wins=wins+?,losses=losses+?,kills=kills+?,deaths=deaths+?,games=games+1,rating=MAX(100,rating+?) WHERE token=?',
                   (wins, losses, kills, deaths, delta, token))
        db.commit()
    return profile_get(token)


def leaderboards():
    with db_connect() as db:
        rows=db.execute('SELECT nick,kills,wins,rating FROM profiles ORDER BY rating DESC, wins DESC, kills DESC LIMIT 10').fetchall()
    return [{'nick':nick,'kills':kills,'wins':wins,'rating':rating} for nick,kills,wins,rating in rows]


def rank_for(r):
    return 'Lenda' if r >= 1700 else 'Diamante' if r >= 1450 else 'Ouro' if r >= 1200 else 'Prata' if r >= 1000 else 'Bronze'


@dataclass
class Connection:
    ws: WebSocket
    token: str
    nick: str
    hero: str = 'pingo'
    mode: str = '1v1'
    queued: Optional[str] = None
    lobby: Optional[str] = None
    match: Optional[str] = None
    connected_at: float = field(default_factory=time.monotonic)


@dataclass
class Combatant:
    token: str
    nick: str
    hero: str
    team: int
    x: float
    y: float = FLOOR
    vx: float = 0
    vy: float = 0
    dir: int = 1
    hp: float = 100
    max_hp: float = 100
    alive: bool = True
    respawn: float = 0
    invuln: float = 1.2
    basic_cd: float = 0
    skill_cd: float = 0
    dash_cd: float = 0
    dash_time: float = 0
    jumps: int = 0
    kills: int = 0
    deaths: int = 0
    last_attack: float = 0
    input_move: int = 0
    want_jump: bool = False
    want_attack: bool = False
    want_skill: bool = False
    want_dash: bool = False


@dataclass
class Lobby:
    code: str
    mode: str
    arena: str
    owner: str
    members: list[str] = field(default_factory=list)
    private: bool = True


@dataclass
class Match:
    id: str
    mode: str
    ranked: bool
    arena: str
    members: list[str]
    players: dict[str, Combatant]
    created: float = field(default_factory=time.monotonic)
    time_left: float = DURATION
    projectiles: list[dict] = field(default_factory=list)
    effects: list[dict] = field(default_factory=list)
    score: list[int] = field(default_factory=lambda: [0, 0])
    finished: bool = False
    next_projectile: int = 0
    zone_r: float = 730


connections: dict[str, Connection] = {}
queues: dict[tuple[str, bool], list[str]] = defaultdict(list)
lobbies: dict[str, Lobby] = {}
matches: dict[str, Match] = {}
server_loop_task: Optional[asyncio.Task] = None


def options_required(mode):
    if mode == 'BR': return 4
    if re.fullmatch(r'1v[1-5]', mode): return int(mode[2]) + 1
    raise ValueError('Modo inválido')


def obstacles(arena):
    if arena == 'torre_eclipse': return [{'x': 338, 'w': 64, 'h': 41}, {'x': 742, 'w': 92, 'h': 48}, {'x': 1161, 'w': 60, 'h': 41}]
    if arena == 'pantano_luar': return [{'x': 275, 'w': 77, 'h': 45}, {'x': 641, 'w': 78, 'h': 34}, {'x': 1078, 'w': 80, 'h': 46}]
    return [{'x': 425, 'w': 70, 'h': 43}, {'x': 945, 'w': 70, 'h': 43}]


async def emit(token, payload):
    conn = connections.get(token)
    if not conn: return
    try:
        await conn.ws.send_json(payload)
    except Exception:
        pass


async def emit_many(tokens, payload):
    await asyncio.gather(*(emit(t, payload) for t in tokens), return_exceptions=True)


async def error(token, msg):
    await emit(token, {'type': 'error', 'message': msg})


async def broadcast_lobby(lobby: Lobby):
    await emit_many(lobby.members, {'type': 'lobby', 'code': lobby.code, 'mode': lobby.mode, 'arena': lobby.arena,
                                    'owner': lobby.owner, 'members': [{'nick': connections[t].nick, 'hero': connections[t].hero} for t in lobby.members if t in connections],
                                    'required': options_required(lobby.mode)})


async def remove_from_lobby(token):
    c = connections.get(token)
    if not c: return
    for q in queues.values():
        if token in q: q.remove(token)
    c.queued = None
    if c.lobby and c.lobby in lobbies:
        l = lobbies[c.lobby]
        if token in l.members: l.members.remove(token)
        c.lobby = None
        if not l.members: lobbies.pop(l.code, None)
        else:
            if l.owner == token: l.owner = l.members[0]
            await broadcast_lobby(l)


def make_match(mode: str, ranked: bool, arena: str, members: list[str]):
    match_id = secrets.token_hex(5)
    n = len(members)
    solo_bonus = (n - 2) if mode.startswith('1v') else 0
    players = {}
    for i, tok in enumerate(members):
        c = connections[tok]
        team = i if mode == 'BR' else 0 if i == 0 else 1
        if mode == 'BR': x = 90 + i * (WORLD_W - 180) / max(1, (n - 1))
        elif i == 0: x = 170
        else: x = WORLD_W - 170 - (i - 1) * 76
        hp = 100 + solo_bonus * 26 if team == 0 and mode != 'BR' else 100
        players[tok] = Combatant(token=tok, nick=c.nick, hero=c.hero, team=team, x=x, hp=hp, max_hp=hp)
        c.match = match_id
        c.queued = None
        c.lobby = None
    match = Match(id=match_id, mode=mode, ranked=ranked, arena=arena, members=list(members), players=players)
    matches[match_id] = match
    return match


async def begin_match(mode, ranked, arena, members):
    m = make_match(mode, ranked, arena, members)
    for tok in members:
        p = m.players[tok]
        await emit(tok, {'type': 'match_start', 'match': m.id, 'mode': mode, 'ranked': ranked, 'arena': arena,
                          'team': p.team, 'hero': p.hero, 'token': tok, 'duration': DURATION,
                          'players': [{'nick': a.nick, 'hero': a.hero, 'team': a.team} for a in m.players.values()]})


async def queue_join(token, mode, ranked):
    c = connections[token]
    if c.match: return await error(token, 'Você já está em uma partida.')
    await remove_from_lobby(token)
    k = (mode, ranked)
    queues[k].append(token)
    c.queued = f'{mode}|{int(ranked)}'
    await emit(token, {'type': 'queued', 'mode': mode, 'ranked': ranked, 'needed': options_required(mode)})
    await check_queue(k)


async def check_queue(k):
    mode, ranked = k
    q = queues[k]
    q[:] = [t for t in q if t in connections and not connections[t].match]
    need = options_required(mode)
    while len(q) >= need:
        selected = q[:need]
        del q[:need]
        # Randomize which player is on the solo team.
        random.shuffle(selected)
        await begin_match(mode, ranked, random.choice(MAPS), selected)


def safe_nick(raw):
    value = str(raw or 'Aventureiro').strip()
    value = re.sub(r'[^\w À-ÿ\-]', '', value, flags=re.UNICODE)[:16]
    return value or 'Aventureiro'


def projectile(m, owner: Combatant, kind, damage, speed, radius=15, vy=0, ttl=1.3, piercing=False):
    m.next_projectile += 1
    m.projectiles.append({'id': m.next_projectile, 'owner': owner.token, 'team': owner.team,
                          'x': owner.x + 28 * owner.dir, 'y': owner.y - 26, 'vx': speed * owner.dir,
                          'vy': vy, 'kind': kind, 'damage': damage, 'r': radius, 'ttl': ttl,
                          'hit': set(), 'pierce': piercing})


def damage_player(m, attacker: Combatant, target: Combatant, damage, push=True):
    if not target.alive or target.invuln > 0 or attacker.token == target.token: return False
    if m.mode != 'BR' and attacker.team == target.team: return False
    if m.mode.startswith('1v') and attacker.team == 0:
        damage *= 1 + .10 * (int(m.mode[-1]) - 1)
    target.hp = max(0, target.hp - damage)
    target.invuln = .3
    if push: target.x = max(24, min(WORLD_W - 24, target.x + attacker.dir * 19))
    m.effects.append({'kind': 'impact', 'x': round(target.x), 'y': round(target.y - 28), 'team': attacker.team})
    if target.hp <= 0:
        target.alive = False
        target.deaths += 1
        target.respawn = 3.0
        attacker.kills += 1
        if m.mode != 'BR': m.score[attacker.team] += 1
        m.effects.append({'kind': 'ko', 'x': round(target.x), 'y': round(target.y - 35), 'team': attacker.team})
    return True


def basic_attack(m, a):
    if a.basic_cd > 0 or not a.alive: return
    a.basic_cd = .48
    a.last_attack = .23
    m.effects.append({'kind': 'slash', 'x': round(a.x + a.dir * 30), 'y': round(a.y - 34), 'dir': a.dir, 'team': a.team})
    for t in m.players.values():
        if t.token == a.token: continue
        dx = (t.x - a.x) * a.dir
        if 0 < dx < 66 and abs(t.y - a.y) < 67:
            damage_player(m, a, t, HERO_BASIC[a.hero])


def use_skill(m, a):
    if a.skill_cd > 0 or not a.alive: return
    a.skill_cd = HERO_SKILL[a.hero][1]
    if a.hero == 'pingo':
        for vy in (-145, 0, 145): projectile(m, a, 'pena', 8, 550, 13, vy, 1.3)
    elif a.hero == 'mila': projectile(m, a, 'fogo', 21, 420, 22, 0, 1.5)
    elif a.hero == 'toru': projectile(m, a, 'terra', 22, 350, 27, 0, 1.8)
    elif a.hero == 'brico': projectile(m, a, 'engrenagem', 21, 410, 23, 0, 1.6)
    elif a.hero == 'lyn': projectile(m, a, 'flecha', 26, 680, 10, 0, 1.6, piercing=True)
    elif a.hero == 'noctis': projectile(m, a, 'foice', 24, 470, 26, 0, 1.2)
    elif a.hero == 'kaze':
        m.effects.append({'kind': 'katanas', 'x': round(a.x + 25 * a.dir), 'y': round(a.y - 34), 'dir': a.dir, 'team': a.team})
        for t in m.players.values():
            if 0 < (t.x - a.x) * a.dir < 125 and abs(t.y - a.y) < 68:
                damage_player(m, a, t, 27)
        a.x = max(20, min(WORLD_W - 20, a.x + a.dir * 65))
    elif a.hero == 'bruma':
        m.effects.append({'kind': 'martelo', 'x': round(a.x + a.dir * 38), 'y': round(a.y - 10), 'dir': a.dir, 'team': a.team})
        for t in m.players.values():
            if abs(t.x - a.x) < 110 and abs(t.y - a.y) < 74:
                damage_player(m, a, t, 29)


def handle_player_physics(m, a, dt):
    a.basic_cd = max(0, a.basic_cd - dt)
    a.skill_cd = max(0, a.skill_cd - dt)
    a.dash_cd = max(0, a.dash_cd - dt)
    a.invuln = max(0, a.invuln - dt)
    a.last_attack = max(0, a.last_attack - dt)
    if not a.alive:
        if m.mode != 'BR':
            a.respawn -= dt
            if a.respawn <= 0:
                a.alive, a.hp, a.y, a.vy, a.invuln = True, a.max_hp, FLOOR, 0, 1.3
                a.x = 170 if a.team == 0 else WORLD_W - 170
        return

    if a.input_move != 0: a.dir = 1 if a.input_move > 0 else -1
    a.vx = a.input_move * 260
    if a.want_jump and a.y >= FLOOR - 1:
        a.vy = -520
        a.y -= 2
    if a.want_dash and a.dash_cd <= 0:
        a.dash_cd, a.dash_time = 3, .20
    if a.want_attack: basic_attack(m, a)
    if a.want_skill: use_skill(m, a)
    a.want_jump = a.want_dash = a.want_attack = a.want_skill = False

    # Sidestep burst, but never disables attack/jump inputs.
    if a.dash_time > 0:
        a.dash_time = max(0, a.dash_time - dt)
        a.vx += 350 * a.dir
    prevx = a.x
    a.x = max(23, min(WORLD_W - 23, a.x + a.vx * dt))
    a.vy += 1320 * dt
    a.y += a.vy * dt
    if a.y >= FLOOR:
        a.y, a.vy = FLOOR, 0
    # Crates have a tangible hitbox; players can leap onto them.
    for o in obstacles(m.arena):
        top = FLOOR - o['h']
        left, right = o['x'], o['x'] + o['w']
        if a.x + 16 <= left or a.x - 16 >= right: continue
        if a.y >= top and prevx < left - 16 and a.x > prevx:
            a.x = left - 17
        elif a.y >= top and prevx > right + 16 and a.x < prevx:
            a.x = right + 17
        elif a.vy >= 0 and a.y - a.vy * dt <= top + 5 and a.y >= top:
            a.y, a.vy = top, 0


def physics_projectiles(m, dt):
    for q in list(m.projectiles):
        q['x'] += q['vx'] * dt
        q['y'] += q['vy'] * dt
        q['ttl'] -= dt
        blocked = any(o['x'] <= q['x'] <= o['x'] + o['w'] and FLOOR - o['h'] <= q['y'] <= FLOOR for o in obstacles(m.arena))
        if blocked or q['ttl'] <= 0 or not -100 < q['x'] < WORLD_W + 100 or q['y'] > FLOOR + 10:
            m.projectiles.remove(q)
            continue
        owner = m.players.get(q['owner'])
        if not owner: continue
        for t in m.players.values():
            if t.token in q['hit'] or not t.alive: continue
            if abs(t.x - q['x']) < q['r'] + 15 and abs(t.y - 24 - q['y']) < q['r'] + 28:
                if damage_player(m, owner, t, q['damage']):
                    q['hit'].add(t.token)
                    if not q['pierce']:
                        m.projectiles.remove(q)
                        break


def match_snapshot(m):
    return {'type': 'snapshot', 'match': m.id, 'mode': m.mode, 'time': round(m.time_left, 1),
            'score': m.score,
            'zone': round(m.zone_r),
            'players': [{'id': p.token, 'nick': p.nick, 'hero': p.hero, 'team': p.team, 'x': round(p.x, 1),
                         'y': round(p.y, 1), 'dir': p.dir, 'hp': round(p.hp), 'maxHp': round(p.max_hp),
                         'alive': p.alive, 'kills': p.kills, 'deaths': p.deaths,
                         'attack': round(p.last_attack, 2), 'skillCd': round(p.skill_cd, 1), 'dashCd': round(p.dash_cd, 1),
                         'invuln': round(p.invuln, 2)} for p in m.players.values()],
            'projectiles': [{'x': round(q['x']), 'y': round(q['y']), 'kind': q['kind'], 'dir': 1 if q['vx'] > 0 else -1, 'id': q['id']} for q in m.projectiles],
            'effects': m.effects[-30:]}


async def conclude(m, forced_winner=None):
    if m.finished: return
    m.finished = True
    if forced_winner is not None:
        winners = set(forced_winner)
    elif m.mode == 'BR':
        live = [p for p in m.players.values() if p.alive]
        winners = {live[0].token} if len(live) == 1 else ({max(m.players.values(), key=lambda p: (p.hp, p.kills)).token} if live else set())
    else:
        winning_team = 0 if m.score[0] > m.score[1] else 1 if m.score[1] > m.score[0] else None
        winners = {p.token for p in m.players.values() if p.team == winning_team} if winning_team is not None else set()
    for tok, p in m.players.items():
        prof = profile_reward(tok, wins=int(tok in winners), losses=int(tok not in winners), kills=p.kills, deaths=p.deaths, rated=m.ranked)
        await emit(tok, {'type': 'match_end', 'won': tok in winners, 'ranked': m.ranked, 'mode': m.mode,
                         'score': m.score, 'profile': prof, 'rank': rank_for(prof['rating']),
                         'results': [{'nick': x.nick, 'hero': x.hero, 'kills': x.kills, 'deaths': x.deaths,
                                      'winner': x.token in winners} for x in sorted(m.players.values(), key=lambda a: -a.kills)]})
        if tok in connections: connections[tok].match = None
    matches.pop(m.id, None)
    await emit_many(list(connections), {'type':'leaderboard','leaders':leaderboards()})


async def tick_loop():
    tick_count = 0
    while True:
        started = time.monotonic()
        await asyncio.sleep(0)
        for m in list(matches.values()):
            if m.finished: continue
            dt = TICK
            m.time_left = max(0, m.time_left - dt)
            m.effects.clear()
            for p in m.players.values(): handle_player_physics(m, p, dt)
            physics_projectiles(m, dt)
            if m.mode == 'BR':
                m.zone_r = max(175, 730 * (m.time_left / DURATION) ** .55)
                for p in m.players.values():
                    if p.alive and abs(p.x - WORLD_W / 2) > m.zone_r:
                        p.hp -= 9 * dt
                        if p.hp <= 0:
                            p.hp, p.alive, p.deaths = 0, False, p.deaths + 1
            if m.mode == 'BR' and sum(p.alive for p in m.players.values()) <= 1:
                await conclude(m)
            elif m.mode != 'BR' and (max(m.score) >= 10 or not any(p.alive or p.respawn > 0 for p in m.players.values())):
                await conclude(m)
            elif m.time_left <= 0:
                await conclude(m)
            elif tick_count % 2 == 0:
                await emit_many(m.members, match_snapshot(m))
        tick_count += 1
        await asyncio.sleep(max(0, TICK - (time.monotonic() - started)))


@app.on_event('startup')
async def startup():
    global server_loop_task
    with db_connect(): pass
    server_loop_task = asyncio.create_task(tick_loop())


@app.on_event('shutdown')
async def shutdown():
    if server_loop_task:
        server_loop_task.cancel()
        try: await server_loop_task
        except asyncio.CancelledError: pass


@app.get('/health')
def health():
    return {'status': 'ok', 'connected': len(connections), 'matches': len(matches),
            'queuing': sum(len(q) for q in queues.values())}


@app.get('/leaderboard')
def leaderboard_api():
    return {'leaders': leaderboards()}


@app.get('/')
def homepage():
    return FileResponse(ROOT / 'index.html')


@app.get('/index.html')
def index_page():
    return FileResponse(ROOT / 'index.html')


@app.get('/online.html')
def online_page():
    return FileResponse(ROOT / 'online.html')


@app.websocket('/ws')
async def websocket_handler(ws: WebSocket):
    await ws.accept()
    token = None
    try:
        hello = await asyncio.wait_for(ws.receive_json(), timeout=15)
        if not isinstance(hello, dict) or hello.get('type') != 'hello':
            await ws.send_json({'type': 'error', 'message': 'Identificação inválida.'})
            return
        given = str(hello.get('token') or '')
        token = given if re.fullmatch(r'[a-f0-9]{32}', given) else secrets.token_hex(16)
        nick = safe_nick(hello.get('nick'))
        if token in connections:
            await ws.send_json({'type': 'error', 'message': 'Este perfil já está conectado em outro dispositivo.'})
            return
        c = Connection(ws, token, nick)
        connections[token] = c
        prof = profile_create(token, nick)
        await emit(token, {'type': 'welcome', 'token': token, 'profile': prof, 'rank': rank_for(prof['rating']),
                           'online': len(connections), 'leaders':leaderboards(), 'skillNames': {k: v[0] for k, v in HERO_SKILL.items()}})
        while True:
            raw = await ws.receive_text()
            if len(raw) > 900: continue
            try: data = json.loads(raw)
            except ValueError: continue
            if not isinstance(data, dict): continue
            kind = data.get('type')
            if kind == 'profile':
                c.nick = safe_nick(data.get('nick', c.nick))
                await emit(token, {'type': 'profile', 'profile': profile_create(token, c.nick)})
            elif kind == 'leaderboard':
                await emit(token, {'type': 'leaderboard', 'leaders': leaderboards()})
            elif kind == 'select':
                hero = data.get('hero', 'pingo')
                if hero in HEROES:
                    c.hero = hero
                    if c.lobby and c.lobby in lobbies: await broadcast_lobby(lobbies[c.lobby])
            elif kind == 'queue':
                try: mode = str(data.get('mode', '1v1')); options_required(mode)
                except ValueError: return await error(token, 'Modo inválido.')
                await queue_join(token, mode, bool(data.get('ranked', False)))
            elif kind == 'cancel':
                await remove_from_lobby(token)
                await emit(token, {'type': 'lobby_left'})
            elif kind == 'create':
                if c.match: continue
                try: mode = str(data.get('mode', '1v1')); options_required(mode)
                except ValueError: continue
                await remove_from_lobby(token)
                code = ''.join(random.choices('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', k=6))
                while code in lobbies: code = ''.join(random.choices('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', k=6))
                arena = data.get('arena') if data.get('arena') in MAPS else random.choice(MAPS)
                lobby = Lobby(code, mode, arena, token, [token])
                lobbies[code] = lobby
                c.lobby = code
                await broadcast_lobby(lobby)
            elif kind == 'join':
                if c.match: continue
                code = str(data.get('code', '')).upper().strip()
                lobby = lobbies.get(code)
                if not lobby: await error(token, 'Sala não encontrada. Confira o código.'); continue
                if len(lobby.members) >= max(options_required(lobby.mode), 2 if lobby.mode == 'BR' else 0):
                    await error(token, 'A sala está cheia.'); continue
                await remove_from_lobby(token)
                lobby.members.append(token)
                c.lobby = code
                await broadcast_lobby(lobby)
            elif kind == 'start':
                if not c.lobby or c.lobby not in lobbies: continue
                lobby = lobbies[c.lobby]
                if lobby.owner != token: continue
                minimum = 2 if lobby.mode == 'BR' else options_required(lobby.mode)
                if len(lobby.members) < minimum:
                    await error(token, f'É preciso ter {minimum} jogadores para começar.'); continue
                lobbies.pop(lobby.code, None)
                await begin_match(lobby.mode, False, lobby.arena, list(lobby.members))
            elif kind == 'input':
                if not c.match or c.match not in matches: continue
                a = matches[c.match].players.get(token)
                if not a: continue
                a.input_move = max(-1, min(1, int(data.get('move', 0))))
                a.want_jump |= bool(data.get('jump'))
                a.want_attack |= bool(data.get('attack'))
                a.want_skill |= bool(data.get('skill'))
                a.want_dash |= bool(data.get('dash'))
            elif kind == 'leave_match':
                if c.match and c.match in matches:
                    m = matches[c.match]
                    if m.mode != 'BR':
                        opponents = [p.token for p in m.players.values() if p.team != m.players[token].team]
                        await conclude(m, forced_winner=opponents)
                    else:
                        m.players[token].alive = False
                        c.match = None
                await emit(token, {'type': 'lobby_left'})
    except (WebSocketDisconnect, asyncio.TimeoutError):
        pass
    except Exception as exc:
        print('WebSocket error:', type(exc).__name__, str(exc)[:100])
    finally:
        if token and token in connections and connections[token].ws == ws:
            if connections[token].match and connections[token].match in matches:
                m = matches[connections[token].match]
                m.players[token].alive = False
                if m.mode != 'BR':
                    opponents = [p.token for p in m.players.values() if p.team != m.players[token].team]
                    await conclude(m, forced_winner=opponents)
            await remove_from_lobby(token)
            connections.pop(token, None)
