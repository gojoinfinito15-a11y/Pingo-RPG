"""Teste de integração executável com servidor local e python websockets.
Instalar: pip install websockets. Executar: python test_pvp.py
"""
import asyncio
import json
import os
from websockets.asyncio.client import connect

URL = os.environ.get('PINGO_WS_TEST', 'ws://127.0.0.1:8000/ws')

async def recv_type(ws, expected):
    for _ in range(300):
        payload = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
        if payload.get('type') == expected: return payload
    raise AssertionError(f'Não recebeu {expected}')

async def connect_player(nick):
    ws = await connect(URL)
    await ws.send(json.dumps({'type': 'hello', 'nick': nick}))
    welcome = await recv_type(ws, 'welcome')
    assert welcome['token'] and welcome['profile']['rating'] >= 100
    return ws

async def test_one_on_one_ranked():
    a, b = await connect_player('ArenaTesteA'), await connect_player('ArenaTesteB')
    await a.send(json.dumps({'type': 'queue', 'mode': '1v1', 'ranked': True}))
    await b.send(json.dumps({'type': 'queue', 'mode': '1v1', 'ranked': True}))
    x, y = await recv_type(a, 'match_start'), await recv_type(b, 'match_start')
    assert x['match'] == y['match'] and x['ranked']
    await a.send(json.dumps({'type': 'input', 'move': 1, 'skill': True}))
    snap = await recv_type(a, 'snapshot')
    assert len(snap['players']) == 2
    await a.send(json.dumps({'type': 'leave_match'}))
    res = await recv_type(b, 'match_end')
    assert res['won'] and res['profile']['wins'] >= 1
    await a.close(); await b.close()

async def test_team_private():
    players = [await connect_player(f'TesteTrio{i}') for i in range(3)]
    await players[0].send(json.dumps({'type': 'create', 'mode': '1v2', 'arena': 'torre_eclipse'}))
    code = (await recv_type(players[0], 'lobby'))['code']
    for p in players[1:]:
        await p.send(json.dumps({'type': 'join', 'code': code}))
        await recv_type(p, 'lobby')
    await players[0].send(json.dumps({'type': 'start'}))
    starts = [await recv_type(p, 'match_start') for p in players]
    assert all(m['mode'] == '1v2' and m['arena'] == 'torre_eclipse' for m in starts)
    await players[0].send(json.dumps({'type': 'leave_match'}))
    assert (await recv_type(players[1], 'match_end'))['won'] in (True, False)
    for p in players: await p.close()

async def test_br_private():
    a,b = await connect_player('BrTesteA'), await connect_player('BrTesteB')
    await a.send(json.dumps({'type': 'create', 'mode': 'BR', 'arena': 'pantano_luar'}))
    code = (await recv_type(a, 'lobby'))['code']
    await b.send(json.dumps({'type': 'join', 'code': code})); await recv_type(b, 'lobby')
    await a.send(json.dumps({'type': 'start'}))
    await recv_type(a, 'match_start'); await recv_type(b, 'match_start')
    await a.send(json.dumps({'type': 'leave_match'}))
    assert (await recv_type(b, 'match_end'))['won']
    await a.close(); await b.close()

async def main():
    await test_one_on_one_ranked(); print('1v1 ranqueada OK')
    await test_team_private(); print('1v2 sala privada OK')
    await test_br_private(); print('BR sala privada OK')

if __name__ == '__main__': asyncio.run(main())
