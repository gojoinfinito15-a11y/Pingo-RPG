# PINGO RPG — Projeto Android Studio (Aventura + PvP + BR)

Este pacote **não é um APK/AAB pronto nem foi publicado na Google Play**. É o **código Android nativo** preparado a partir da última versão unificada do Pingo RPG, com o jogo original preservado em `app/src/main/assets/index.html`.

## O que está incluído

- Um único aplicativo Pingo RPG com os três modos: **Aventura, PvP e BR**.
- Orientação horizontal bloqueada pelo Android, desde o ícone inicial (sem esperar clique na página HTML).
- Tela cheia imersiva, escondendo barras do sistema; gestos do aparelho podem revelá-las temporariamente.
- A campanha é incluída no app e funciona sem servidor; arquivos de heróis são locais.
- O jogo online mantém o campo para informar o servidor `wss://.../ws`.
- Importação de saves por seletor nativo de arquivos; suporte para exportar saves iniciados via link `blob:` do jogo.
- Ícone Pingo e material preliminar de divulgação em `play_store/`.
- O código Python do servidor PvP em `servidor/` (é um servidor separado, não executado dentro do APK).

## Como gerar APK para testes / AAB para a Play Store

1. Num computador com **Android Studio atualizado**, abra a pasta `Pingo_RPG_Android_Studio` em **File → Open**.
2. Configure o SDK Android **API 36** e o **JDK 17**. A primeira sincronização Gradle precisa da internet para baixar dependências.
3. Este projeto não inclui um binário `gradle-wrapper.jar`; se o Studio não configurar o Gradle automaticamente, instale Gradle 8.13 e execute `gradle wrapper --gradle-version 8.13` na raiz do projeto, depois sincronize. Alternativamente copie o Gradle Wrapper padrão de um projeto novo criado pelo Android Studio.
4. Conecte um aparelho Android ou abra o emulador. Clique **Run ▶** e teste a seleção, a aventura, o inventário, os saves, a entrada em PvP/BR e a tela cheia.
5. Gere o APK de teste no menu **Build → Build APK(s)**. Para publicar na Play Store, use **Build → Generate Signed Bundle / APK... → Android App Bundle** e crie um certificado de upload. **Guarde a chave de assinatura em segurança.**
6. Escolha um identificador definitivo para o app antes do primeiro envio: em `app/build.gradle`, altere `applicationId`, e sincronize. **Não reutilize um ID que pertença a terceiros.**

## PvP e BR online

O servidor incluído em `servidor/` precisa ser executado **fora do celular**, em um serviço de hospedagem com HTTPS/WSS (WebSockets seguros). Com o servidor publicado, edite em `app/build.gradle`:

`buildConfigField 'String', 'PVP_SERVER_URL', '"wss://SEU-DOMINIO/ws"'`

ou peça ao jogador que digite o endereço dentro da Arena Online.

O app **não oferece servidor grátis ilimitado**, não possui infraestrutura de produção nem moderação/administração de nicknames; o servidor de exemplo é uma base de testes. Antes de receber jogadores em público, verifique segurança, autenticação, abuso, proteção das estatísticas e privacidade. Não colete nomes reais ou outras informações pessoais desnecessárias.

## Saves

O Android WebView tem armazenamento local próprio; **os saves do Chrome não são importados automaticamente**. Na versão antiga, use Exportar Save. Depois, no aplicativo Android, use Importar Save. Teste também se o arquivo exportado está íntegro. Nunca presuma que a instalação/desinstalação preservará o save.

## Publicação na Play Store

- É necessária uma conta de desenvolvedor do Google Play Console, mantida por uma pessoa **com 18 anos ou mais**. Para um criador menor de idade, um responsável adulto pode gerenciar a conta em seu próprio nome e cumprir as regras; não use dados falsos nem contorne verificação de idade.
- Taxa de inscrição oficial: **US$ 25 uma vez**, sujeita a condições locais.
- Para contas pessoais novas, exige-se **teste fechado com 12 participantes por 14 dias consecutivos** antes de solicitar acesso a produção.
- Em novembro/2026, o app novo precisa mirar **Android 16 / API 36**.
- Prepare nome, descrição, ícone 512×512, banner 1024×500, capturas reais do aplicativo Android, classificação indicativa, questionário de segurança de dados e **política de privacidade pública e verdadeira**.
- Use os arquivos `play_store/` como rascunho. As imagens são prévias do jogo e não substituem screenshots reais do aplicativo publicado.
- Verifique os direitos de uso de **todas as imagens, fontes, músicas e conteúdos incorporados**, especialmente qualquer arte obtida de sites de banco de imagens. Recursos de terceiros podem precisar de licença de distribuição comercial.
- Para o PvP, explique o uso de nicknames, endereço de IP, métricas de partidas e estatísticas aos usuários, se realmente coletados/guardados pelo servidor. Implemente exclusão de dados conforme aplicável.

## Limitações desta entrega

- Não gerei nem assinei um APK/AAB aqui: este ambiente não tem Android SDK / Gradle configurados. **É preciso compilar e testar no Android Studio.**
- O projeto contém código do jogo, não uma conta do Play Console nem um servidor hospedado.
- É possível que algum mecanismo do HTML precise de ajuste em aparelhos Android específicos. Teste antes de enviar à loja.

## Arquivos principais

- `app/src/main/java/com/pingorpg/aventura/MainActivity.java`: app nativo, fullscreen e WebView.
- `app/src/main/assets/index.html`: jogo unificado original.
- `app/src/main/assets/assets/`: sprites locais.
- `servidor/server.py`: servidor Python da arena PvP/BR.
- `play_store/`: ícone, banner e prévias.
