package com.pingorpg.aventura;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONObject;
import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final int FILE_OPEN_CODE = 202;
    private static final int FILE_SAVE_CODE = 203;
    private WebView game;
    private android.webkit.ValueCallback<Uri[]> chooseFileCallback;
    private byte[] pendingExport;
    private String pendingMime;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hideSystemBars();

        game = new WebView(this);
        game.setBackgroundColor(Color.rgb(6,20,38));
        game.setOverScrollMode(View.OVER_SCROLL_NEVER);
        game.setHorizontalScrollBarEnabled(false);
        game.setVerticalScrollBarEnabled(false);
        game.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        game.setFocusableInTouchMode(true);
        setContentView(game);

        WebSettings settings = game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // necessário ao importar o save escolhido pelo usuário
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        game.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if ("https".equals(uri.getScheme()) && LOCAL_HOST.equals(uri.getHost())) return false;
                // Links externos abrem no navegador, não dentro do jogo.
                if ("https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ignored) { Toast.makeText(MainActivity.this,"Navegador indisponível",Toast.LENGTH_LONG).show(); }
                }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                // Se houver servidor de produção configurado, preenche apenas na primeira utilização.
                if (BuildConfig.PVP_SERVER_URL.startsWith("wss://")) {
                    String json = JSONObject.quote(BuildConfig.PVP_SERVER_URL);
                    view.evaluateJavascript("if(!localStorage.getItem('pingo-pvp-server'))localStorage.setItem('pingo-pvp-server',"+json+");",null);
                }
            }
        });
        game.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooseFileCallback != null) chooseFileCallback.onReceiveValue(null);
                chooseFileCallback=callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {startActivityForResult(intent, FILE_OPEN_CODE);return true;}
                catch (ActivityNotFoundException ex) {chooseFileCallback=null;return false;}
            }
            @Override public void onPermissionRequest(PermissionRequest request) { request.deny(); }
        });
        game.addJavascriptInterface(new ExportSaveBridge(), "PingoAndroidSave");
        game.setDownloadListener((url, userAgent, disposition, type, length) -> {
            if (url.startsWith("blob:")) {
                String file="pingo_rpg_save.json";
                if (disposition != null && disposition.contains("filename=")) {
                    file=disposition.substring(disposition.indexOf("filename=")+9).replace("\"", "").trim();
                }
                String js="(async()=>{try{const blob=await(await fetch("+JSONObject.quote(url)+")).blob();"
                    +"const reader=new FileReader();reader.onloadend=()=>{const raw=String(reader.result).split(',')[1];"
                    +"PingoAndroidSave.saveBase64("+JSONObject.quote(file)+",blob.type||'application/json',raw);};reader.readAsDataURL(blob);"
                    +"}catch(err){console.error('Erro ao exportar save',err);}})();";
                game.evaluateJavascript(js,null);
            } else if (url.startsWith("data:")) {
                String js="(()=>{try{const a="+JSONObject.quote(url)+";const i=a.indexOf(',');"
                    +"PingoAndroidSave.saveBase64('pingo_rpg_save.json','application/json',a.slice(i+1));}catch(e){console.error(e);}})();";
                game.evaluateJavascript(js,null);
            } else if (url.startsWith("https://")) {
                try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); } catch(Exception ignored) {}
            }
        });
        game.loadUrl(START_URL);
    }

    public final class ExportSaveBridge {
        @JavascriptInterface public void saveBase64(String filename,String mime,String encoded) {
            if (encoded == null || encoded.length() > 15_000_000) return;
            final byte[] decoded;
            try { decoded=Base64.decode(encoded,Base64.DEFAULT); } catch(IllegalArgumentException error) { return; }
            runOnUiThread(()->{
                pendingExport=decoded;pendingMime=(mime!=null && mime.length()<100)?mime:"application/json";
                String safe=(filename==null?"pingo_rpg_save.json":filename).replaceAll("[^a-zA-Z0-9._-]","_");
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingMime);
                intent.putExtra(Intent.EXTRA_TITLE,safe);
                try {startActivityForResult(intent,FILE_SAVE_CODE);}catch(Exception e){
                    Toast.makeText(MainActivity.this,"Não foi possível abrir o salvamento",Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int code,int resultCode,Intent data) {
        super.onActivityResult(code,resultCode,data);
        if(code==FILE_OPEN_CODE){
            if(chooseFileCallback!=null){
                chooseFileCallback.onReceiveValue(resultCode==RESULT_OK && data!=null && data.getData()!=null?new Uri[]{data.getData()}:null);
                chooseFileCallback=null;
            }
        } else if(code==FILE_SAVE_CODE){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingExport!=null){
                try (OutputStream stream=getContentResolver().openOutputStream(data.getData())) {
                    if(stream!=null){stream.write(pendingExport);Toast.makeText(this,"Save exportado!",Toast.LENGTH_SHORT).show();}
                }catch(Exception e){Toast.makeText(this,"Falha ao exportar save",Toast.LENGTH_LONG).show();}
            }
            pendingExport=null;
        }
    }

    private void hideSystemBars(){
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller=getWindow().getInsetsController();
            if(controller!=null){controller.hide(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}
        }else{
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)hideSystemBars();}
    @Override protected void onResume(){super.onResume();if(game!=null)game.onResume();hideSystemBars();}
    @Override protected void onPause(){if(game!=null)game.onPause();super.onPause();}
    @Override public void onBackPressed(){
        new AlertDialog.Builder(this)
            .setTitle("Sair do Pingo RPG?")
            .setMessage("Seu progresso deve ser salvo pelo menu do jogo.")
            .setNegativeButton("Continuar jogando",(dialog,which)->{})
            .setPositiveButton("Sair",(dialog,which)->finish()).show();
    }
    @Override protected void onDestroy(){
        if(game!=null){game.removeJavascriptInterface("PingoAndroidSave");game.destroy();game=null;}
        super.onDestroy();
    }
}
