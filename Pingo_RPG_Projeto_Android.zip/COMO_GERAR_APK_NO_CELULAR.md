# Pingo RPG — gerar APK usando apenas um celular

Este ZIP contém o **projeto Android**, não um APK compilado. Foi acrescentado um fluxo de trabalho do GitHub Actions para compilar um **APK de teste** em um computador na nuvem, sem Android Studio no celular.

## Como usar

1. Extraia o ZIP no app de Arquivos do celular. A pasta do projeto contém `settings.gradle`, `app/` e `.github/workflows/gerar-apk.yml`.
2. Crie um repositório GitHub **privado** pelo navegador em `github.com` (não coloque informações pessoais, senhas nem chaves no repositório). Carregue **o conteúdo extraído**, mantendo a estrutura de pastas. **Enviar apenas o ZIP como arquivo não funciona**, pois o GitHub não o descompacta automaticamente.
3. No repositório, abra **Actions → Gerar APK do Pingo RPG → Run workflow**. A execução usa Java 17, SDK Android 36 e Gradle 8.13.
4. Se a compilação funcionar, abra a execução terminada → **Artifacts → Pingo-RPG-APK-teste**. Baixe o artefato, extraia seu ZIP e terá um `.apk` de teste para instalar no seu Android.
5. Se a execução falhar, abra o registro da etapa vermelha. O projeto **ainda não foi compilado/validado em nuvem**, portanto podem ser necessários ajustes.

O processo de envio de uma pasta inteira pelo celular pode ser complicado no GitHub, dependendo do navegador. É possível usar uma ferramenta de edição Git que suporte criar pastas e enviar os arquivos preservando os caminhos. Não compartilhe credenciais com terceiros.

## Importante para a Play Store

- Este fluxo gera **APK de teste**, não um **AAB de produção assinado**.
- Publicar na Google Play exige conta de desenvolvedor mantida por alguém de **18 anos ou mais**. Um responsável pode conduzir essa parte com os dados dele, segundo as regras do Google.
- Antes de publicar, é preciso configurar assinatura segura, gerar AAB, testar em aparelhos, revisar privacidade e hospedar o servidor de PvP/BR.
- **Nunca publique chaves de assinatura, arquivos `.jks`, tokens ou senhas no GitHub**; não inclua segredos no ZIP. O processo de assinatura deve ser conduzido com segurança pelo responsável.
- A aventura funciona com arquivos locais. O PvP/BR de jogadores diferentes precisa de servidor online real.
